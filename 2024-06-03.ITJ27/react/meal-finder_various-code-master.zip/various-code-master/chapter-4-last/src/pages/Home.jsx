const Home = () => {
    return (
        <h3>今夜のレシピをみつけよう</h3>
    )
}

export default Home