import Recipe from "../components/Recipe"

const Meal = () => {
    return (
        <>
            <Recipe/>
        </>
    )
}

export default Meal