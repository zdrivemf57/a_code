# コード集
「Reactマスターブック Zero to HERO」（三好アキ著）

第6章各項目のコードです。

Reactバージョン18, Next.jsバージョン14