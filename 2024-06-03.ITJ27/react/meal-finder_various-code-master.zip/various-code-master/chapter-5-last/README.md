# レシピアプリ
「Reactマスターブック Zero to HERO」（三好アキ著）

第5章useContext導入時点のソースコードです。

Reactバージョン18, react-router-domバージョン6

アプリを起動するには、ファイルをダウンロード後にターミナルで`npm install`を実行し、必要なパッケージをダウンロードする必要があります。