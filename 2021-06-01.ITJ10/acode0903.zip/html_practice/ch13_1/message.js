/*
 こんにちはと表示
*/
// 変数の利用
let msg = "こんにちは";
console.log(msg);

msg = 100;
console.log(msg);

const name = "山田太郎";

name = "佐藤";
console.log(name);
